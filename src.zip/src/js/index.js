require(['require.config'], () =>{
    require(['url','template','header','footer'], (url,template) =>{
        class Index{
            constructor () {

            }
            getType () {
                $.get(url.rapBaseUrl + 'index/type',data =>{
                    if(data.res_code === 1){
                        this.renderType(data.res_body.list);
                    }
                })
            }
            renderType (list) {
                console.log(template);
                let html = template("")
            }
        }
    })
})