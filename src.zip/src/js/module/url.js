// url模块
//一开始使用假数据，将来换成真的数据以后只需要在这个地方修改baseUrl
define( () => {
    return {
        rapBaseUrl : "http://rap2api.taobao.org/app/mock/166415/",
        phpBaseUrl : "http://localhost/NBAStore/api/v1/"
    }
});